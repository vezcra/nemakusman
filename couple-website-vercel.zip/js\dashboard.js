(function () {
  "use strict";

  const config = window.COUPLE_CONFIG;
  const discord = window.CoupleDiscord;
  const states = {};
  const spotifyProgress = new Map();
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const finePointer = window.matchMedia("(pointer: fine)");

  const STATUS = {
    online: { label: "Online", tone: "online" },
    idle: { label: "Idle", tone: "idle" },
    dnd: { label: "Do not disturb", tone: "dnd" },
    offline: { label: "Offline", tone: "offline" }
  };

  const ACTIVITY_LABELS = {
    0: "Playing",
    1: "Streaming",
    2: "Listening",
    3: "Watching",
    5: "Competing"
  };

  const LINK_ICONS = {
    discord: "i-discord",
    audiomack: "i-wave",
    lanyard: "i-link",
    spotify: "i-spotify"
  };

  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function $$(selector, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(selector));
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function safeText(value, fallback) {
    const text = String(value == null ? "" : value).trim();
    return text || fallback || "";
  }

  function formatDate(value) {
    if (!value) return "∞";
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) return "∞";
    return new Intl.DateTimeFormat("en-GB", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    }).format(date);
  }

  function snowflakeDate(id) {
    try {
      return new Date(Number((BigInt(id) >> 22n) + 1420070400000n));
    } catch (error) {
      return null;
    }
  }

  function formatClock(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const minutes = Math.floor(total / 60);
    const seconds = total % 60;
    return minutes + ":" + String(seconds).padStart(2, "0");
  }

  function setImage(image, src, fallback) {
    if (!image) return;
    const fallbackSrc = fallback || image.getAttribute("data-fallback") || "";
    image.onerror = function () {
      image.onerror = null;
      if (fallbackSrc && image.getAttribute("src") !== fallbackSrc) {
        image.setAttribute("src", fallbackSrc);
      } else {
        image.style.visibility = "hidden";
      }
    };
    if (src) {
      image.setAttribute("src", src);
    } else if (fallbackSrc) {
      image.setAttribute("src", fallbackSrc);
    }
  }

  function profileState(key) {
    if (states[key]) return states[key];
    if (discord) return discord.getState(key);
    return { phase: "loading", data: null, error: null };
  }

  function phaseLabel(state) {
    if (!state) return { label: "Connecting", tone: "unknown" };
    if (state.phase === "loading") return { label: "Connecting", tone: "unknown" };
    if (state.phase === "not_connected") return { label: "No signal", tone: "offline" };
    if (state.phase === "error") return { label: "Connection lost", tone: "offline" };
    const status = STATUS[state.data && state.data.status] || STATUS.offline;
    return { label: status.label, tone: status.tone };
  }

  function displayName(key, state) {
    const profile = config.profiles[key];
    if (state && state.data && state.data.user) {
      return safeText(state.data.user.displayName || state.data.user.globalName || state.data.user.username, profile.fallbackName);
    }
    return profile.fallbackName;
  }

  function displayHandle(key, state) {
    const profile = config.profiles[key];
    if (state && state.data && state.data.user && state.data.user.username) {
      return "@" + state.data.user.username;
    }
    if (state && state.phase === "not_connected") return "waiting for Lanyard";
    return profile.fallbackUsername ? "@" + profile.fallbackUsername : "waiting for signal";
  }

  function activityImage(activity) {
    const image = activity && activity.assets && activity.assets.large_image;
    if (!image) return "";
    if (/^https?:\/\//i.test(image)) return image;
    if (image.indexOf("mp:") === 0) return "https://media.discordapp.net/" + image.slice(3);
    if (image.indexOf("spotify:") === 0) return "https://i.scdn.co/image/" + image.slice(8);
    if (activity.application_id) {
      return "https://cdn.discordapp.com/app-assets/" + activity.application_id + "/" + image + ".png";
    }
    return "";
  }

  function currentActivity(state) {
    if (!state || !state.data) return null;
    const activities = Array.isArray(state.data.activities) ? state.data.activities : [];
    return activities.find(function (activity) {
      return Number(activity.type) !== 4;
    }) || null;
  }

  function spotifyCard(key, spotify, profile) {
    const art = spotify.album_art_url || profile.music.artworkFallback;
    const start = spotify.timestamps && spotify.timestamps.start ? Number(spotify.timestamps.start) : 0;
    const end = spotify.timestamps && spotify.timestamps.end ? Number(spotify.timestamps.end) : 0;
    const duration = Math.max(0, end - start);
    const elapsed = start ? Math.min(duration, Math.max(0, Date.now() - start)) : 0;
    const progress = duration ? Math.max(0, Math.min(100, (elapsed / duration) * 100)) : 0;
    const source = spotify.track_id ? "https://open.spotify.com/track/" + spotify.track_id : "https://open.spotify.com";

    spotifyProgress.set(key, { start: start, end: end, duration: duration });

    return [
      '<div class="live-now">',
      '  <span class="live-now__art">',
      '    <img src="' + escapeHtml(art) + '" alt="" width="46" height="46" data-spotify-art="' + escapeHtml(key) + '" data-fallback="' + escapeHtml(profile.music.artworkFallback) + '">',
      '  </span>',
      '  <div class="live-now__body">',
      '    <span class="live-now__eyebrow"><svg class="icon" aria-hidden="true"><use href="#i-spotify"></use></svg>Spotify · live</span>',
      '    <strong class="live-now__title">' + escapeHtml(spotify.song || "Unknown track") + "</strong>",
      '    <span class="live-now__sub">' + escapeHtml(spotify.artist || "Unknown artist") + "</span>",
      "  </div>",
      '  <a class="live-now__link" href="' + escapeHtml(source) + '" target="_blank" rel="noopener noreferrer" aria-label="Open on Spotify"><svg class="icon" aria-hidden="true"><use href="#i-external"></use></svg></a>',
      '  <div class="live-now__progress">',
      '    <span data-spotify-time="' + escapeHtml(key) + '">' + formatClock(elapsed) + "</span>",
      '    <span class="live-now__bar"><span data-spotify-progress="' + escapeHtml(key) + '" style="--progress:' + progress.toFixed(2) + '%"></span></span>',
      '    <span>' + (duration ? formatClock(duration) : "live") + "</span>",
      "  </div>",
      "</div>"
    ].join("");
  }

  function activityCard(activity) {
    const image = activityImage(activity);
    const type = ACTIVITY_LABELS[Number(activity.type)] || "Activity";
    const detail = activity.details || activity.state || activity.name || "Active";
    const media = image
      ? '<img src="' + escapeHtml(image) + '" alt="" width="46" height="46">'
      : '<span aria-hidden="true">' + escapeHtml(safeText(activity.name, "?").charAt(0).toUpperCase()) + "</span>";

    return [
      '<div class="live-now">',
      '  <span class="live-now__art">' + media + "</span>",
      '  <div class="live-now__body">',
      '    <span class="live-now__eyebrow"><svg class="icon" aria-hidden="true"><use href="#i-activity"></use></svg>' + escapeHtml(type) + "</span>",
      '    <strong class="live-now__title">' + escapeHtml(activity.name || "Activity") + "</strong>",
      '    <span class="live-now__sub">' + escapeHtml(detail) + "</span>",
      "  </div>",
      "</div>"
    ].join("");
  }

  function emptyCard(key, state) {
    if (state && state.phase === "not_connected") {
      return [
        '<div class="live-empty">',
        '  <span class="live-empty__icon"><svg class="icon" aria-hidden="true"><use href="#i-link"></use></svg></span>',
        "  <div><strong>Waiting for Lanyard</strong><span>Join the <a href=\"" + escapeHtml(config.site.lanyardInvite) + '" target="_blank" rel="noopener noreferrer">Lanyard server</a> to enable live presence.</span></div>',
        "</div>"
      ].join("");
    }

    if (state && state.phase === "error") {
      return [
        '<div class="live-empty">',
        '  <span class="live-empty__icon"><svg class="icon" aria-hidden="true"><use href="#i-activity"></use></svg></span>',
        '  <div><strong>No connection</strong><span>Lanyard is not responding right now. Retrying in a few minutes.</span></div>',
        "</div>"
      ].join("");
    }

    return [
      '<div class="live-empty">',
      '  <span class="live-empty__icon"><svg class="icon" aria-hidden="true"><use href="#i-activity"></use></svg></span>',
      '  <div><strong>Quiet right now</strong><span>Games, Spotify, and custom status will appear here.</span></div>',
      "</div>"
    ].join("");
  }

  function renderActivity(key, state) {
    const root = $('[data-profile="' + key + '"] [data-profile-activity]');
    if (!root) return;
    const profile = config.profiles[key];

    if (!state || state.phase === "loading") return;

    if (state.phase !== "ready") {
      root.innerHTML = emptyCard(key, state);
      return;
    }

    const spotify = state.data && state.data.spotify;
    if (spotify) {
      root.innerHTML = spotifyCard(key, spotify, profile);
      const art = $('[data-spotify-art="' + key + '"]', root);
      setImage(art, spotify.album_art_url, profile.music.artworkFallback);
      return;
    }

    const activity = currentActivity(state);
    if (activity) {
      root.innerHTML = activityCard(activity);
      return;
    }

    const custom = state.data && state.data.customStatus;
    if (custom && (custom.state || custom.name)) {
      root.innerHTML = [
        '<div class="live-empty">',
        '  <span class="live-empty__icon"><svg class="icon" aria-hidden="true"><use href="#i-sparkle"></use></svg></span>',
        "  <div><strong>Custom status</strong><span>" + escapeHtml(custom.state || custom.name) + "</span></div>",
        "</div>"
      ].join("");
      return;
    }

    root.innerHTML = emptyCard(key, state);
  }

  function renderLinks(key) {
    const profile = config.profiles[key];
    const root = $('[data-profile="' + key + '"] [data-profile-links]');
    if (!root) return;
    const links = Array.isArray(profile.links) ? profile.links : [];
    root.innerHTML = links.map(function (link) {
      const icon = LINK_ICONS[String(link.label || "").toLowerCase()] || "i-external";
      return [
        '<a href="' + escapeHtml(link.url) + '" target="_blank" rel="noopener noreferrer" aria-label="' + escapeHtml(link.label) + '" title="' + escapeHtml(link.label) + '">',
        '  <svg class="icon" aria-hidden="true"><use href="#' + icon + '"></use></svg>',
        "</a>"
      ].join("");
    }).join("");
  }

  function renderPlatforms(key, state) {
    const root = $('[data-profile="' + key + '"] [data-profile-platforms]');
    if (!root) return;
    if (!state || state.phase !== "ready" || !state.data) {
      root.innerHTML = "";
      return;
    }
    const platforms = state.data.platforms || {};
    const items = [
      { key: "desktop", label: "PC" },
      { key: "mobile", label: "MOB" },
      { key: "web", label: "WEB" }
    ];
    root.innerHTML = items.map(function (item) {
      return '<span class="' + (platforms[item.key] ? "is-on" : "") + '" title="' + item.label + '">' + item.label + "</span>";
    }).join("");
  }

  function renderProfile(key, state) {
    const profile = config.profiles[key];
    const root = $('[data-profile="' + key + '"]');
    if (!root || !profile) return;

    const phase = phaseLabel(state);
    const name = displayName(key, state);
    const handle = displayHandle(key, state);
    const avatar = $("[data-profile-avatar]", root);
    const avatarUrl = state && state.data && state.data.user && state.data.user.avatarUrl;

    setImage(avatar, avatarUrl || profile.avatarFallback, profile.avatarFallback);

    $$("[data-profile-name]", root).forEach(function (node) {
      node.textContent = name;
    });
    $$("[data-profile-username]", root).forEach(function (node) {
      node.textContent = handle;
    });
    $$("[data-profile-bio]", root).forEach(function (node) {
      node.textContent = profile.bio || "";
    });
    $$("[data-profile-status]", root).forEach(function (node) {
      node.textContent = phase.label;
    });
    $$("[data-profile-status-dot]", root).forEach(function (node) {
      node.setAttribute("data-status", phase.tone);
    });

    const joined = snowflakeDate(profile.discordId);
    const joinedNode = $("[data-profile-joined]", root);
    if (joinedNode) joinedNode.textContent = joined ? formatDate(joined) : "—";

    const activities = state && state.data && Array.isArray(state.data.activities) ? state.data.activities : [];
    const games = activities.filter(function (activity) {
      return Number(activity.type) === 0;
    }).length;
    const gamesNode = $("[data-profile-games]", root);
    if (gamesNode) {
      gamesNode.textContent = state && state.phase === "ready" ? String(games) : "—";
    }

    const activity = currentActivity(state);
    const activityNameNode = $("[data-profile-activity-name]", root);
    if (activityNameNode) {
      if (!state || state.phase !== "ready") {
        activityNameNode.textContent = "—";
      } else if (state.data && state.data.spotify) {
        activityNameNode.textContent = "Spotify";
      } else if (activity) {
        activityNameNode.textContent = safeText(activity.name, "—");
      } else {
        activityNameNode.textContent = "Silent";
      }
    }

    renderPlatforms(key, state);
    renderActivity(key, state);
  }

  function renderLove() {
    const meState = profileState("me");
    const herState = profileState("her");
    const meName = displayName("me", meState);
    const herName = displayName("her", herState);
    const mePhase = phaseLabel(meState);
    const herPhase = phaseLabel(herState);
    const meOnline = meState.phase === "ready" && meState.data && meState.data.status !== "offline";
    const herOnline = herState.phase === "ready" && herState.data && herState.data.status !== "offline";
    const onlineCount = Number(meOnline) + Number(herOnline);
    const signal = $("[data-love-status]");
    const signalText = $("[data-love-status-text]");
    const onlineNode = $("[data-love-online]");
    const sinceNode = $("[data-love-since]");

    $$('[data-love-name="me"]').forEach(function (node) {
      node.textContent = meName;
    });
    $$('[data-love-name="her"]').forEach(function (node) {
      node.textContent = herName;
    });

    const meAvatar = $('[data-love-avatar="me"]');
    const herAvatar = $('[data-love-avatar="her"]');
    setImage(meAvatar, meState.data && meState.data.user ? meState.data.user.avatarUrl : config.profiles.me.avatarFallback, config.profiles.me.avatarFallback);
    setImage(herAvatar, herState.data && herState.data.user ? herState.data.user.avatarUrl : config.profiles.her.avatarFallback, config.profiles.her.avatarFallback);

    const meDot = $('[data-love-dot="me"]');
    const herDot = $('[data-love-dot="her"]');
    if (meDot) meDot.setAttribute("data-status", mePhase.tone);
    if (herDot) herDot.setAttribute("data-status", herPhase.tone);

    if (onlineNode) onlineNode.textContent = onlineCount + " / 2";

    if (sinceNode) {
      sinceNode.textContent = config.site.since ? formatDate(config.site.since) : "∞";
    }

    if (signal && signalText) {
      if (onlineCount === 2) {
        signal.setAttribute("data-love-status", "live");
        signalText.textContent = "together online";
      } else if (onlineCount === 1) {
        signal.setAttribute("data-love-status", "waiting");
        signalText.textContent = "waiting for signal";
      } else if (meState.phase === "loading" || herState.phase === "loading") {
        signal.setAttribute("data-love-status", "connecting");
        signalText.textContent = "connecting";
      } else {
        signal.setAttribute("data-love-status", "waiting");
        signalText.textContent = "no signal";
      }
    }
  }

  function liveSpotifyFor(key) {
    const state = profileState(key);
    if (state.phase === "ready" && state.data && state.data.spotify) {
      return state.data.spotify;
    }
    return null;
  }

  function renderNowbar() {
    Object.keys(config.profiles).forEach(function (key) {
      const profile = config.profiles[key];
      const spotify = liveSpotifyFor(key);
      const cover = $('[data-now-cover="' + key + '"]');
      const title = $('[data-now-title="' + key + '"]');
      const subtitle = $('[data-now-subtitle="' + key + '"]');
      const eyebrow = $('[data-now-eyebrow="' + key + '"]');
      const live = Boolean(spotify);

      setImage(cover, spotify ? spotify.album_art_url : profile.music.artwork, profile.music.artworkFallback);

      if (title) title.textContent = spotify ? spotify.song : profile.music.title;
      if (subtitle) subtitle.textContent = spotify ? spotify.artist : profile.music.artist;

      if (eyebrow) {
        eyebrow.textContent = live ? "Live · Spotify" : "Now playing · " + (key === "me" ? "me" : "her");
      }
    });
  }

  function renderMusicCard(key) {
    const profile = config.profiles[key];
    const cover = $('[data-music-cover="' + key + '"]');
    const title = $('[data-music-title="' + key + '"]');
    const subtitle = $('[data-music-subtitle="' + key + '"]');
    const artist = $('[data-music-artist="' + key + '"]');
    const provider = $('[data-music-provider="' + key + '"]');
    const duration = $('[data-music-duration="' + key + '"]');
    const providerLabels = { youtube: "YouTube", spotify: "Spotify", audiomack: "Audiomack", audio: "Audio" };
    if (cover) setImage(cover, profile.music.artwork, profile.music.artworkFallback);
    if (title) title.textContent = profile.music.title;
    if (subtitle) subtitle.textContent = profile.music.subtitle;
    if (artist) artist.textContent = profile.music.artist;
    if (provider) provider.textContent = "on " + (providerLabels[profile.music.provider] || "source");
    if (duration) duration.textContent = profile.music.durationLabel || "0:00";
  }

  function updateSpotifyProgress() {
    spotifyProgress.forEach(function (data, key) {
      if (!data.start || !data.end) return;
      const now = Date.now();
      const elapsed = Math.min(data.duration, Math.max(0, now - data.start));
      const progress = data.duration ? Math.max(0, Math.min(100, (elapsed / data.duration) * 100)) : 0;
      const bar = $('[data-spotify-progress="' + key + '"]');
      const time = $('[data-spotify-time="' + key + '"]');
      if (bar) bar.style.setProperty("--progress", progress.toFixed(2) + "%");
      if (time) time.textContent = formatClock(elapsed);
    });
  }

  function createStars() {
    const root = $("[data-stars]");
    if (!root) return;
    const count = reduceMotion.matches ? 26 : 68;
    const fragment = document.createDocumentFragment();
    for (let index = 0; index < count; index += 1) {
      const star = document.createElement("span");
      star.className = "sky__star";
      star.style.left = (Math.random() * 100).toFixed(2) + "%";
      star.style.top = (Math.random() * 100).toFixed(2) + "%";
      star.style.setProperty("--size", (Math.random() * 2.2 + 0.7).toFixed(2) + "px");
      star.style.setProperty("--opacity", (Math.random() * 0.55 + 0.25).toFixed(2));
      star.style.setProperty("--duration", (Math.random() * 4 + 2.8).toFixed(2) + "s");
      star.style.setProperty("--delay", (-Math.random() * 6).toFixed(2) + "s");
      fragment.appendChild(star);
    }
    root.appendChild(fragment);
  }

  function createPetals() {
    const root = $("[data-petals]");
    if (!root) return;
    const count = reduceMotion.matches ? 3 : 15;
    const fragment = document.createDocumentFragment();
    for (let index = 0; index < count; index += 1) {
      const petal = document.createElement("span");
      petal.className = "sky__petal";
      petal.style.setProperty("--x", (Math.random() * 100).toFixed(2) + "%");
      petal.style.setProperty("--size", (Math.random() * 10 + 6).toFixed(2) + "px");
      petal.style.setProperty("--duration", (Math.random() * 12 + 12).toFixed(2) + "s");
      petal.style.setProperty("--delay", (-Math.random() * 20).toFixed(2) + "s");
      petal.style.setProperty("--drift", (Math.random() * 140 - 70).toFixed(2) + "px");
      fragment.appendChild(petal);
    }
    root.appendChild(fragment);
  }

  function setupTheme() {
    const toggle = $("[data-theme-toggle]");
    const meta = document.querySelector('meta[name="theme-color"]');
    let theme = "dark";
    try {
      theme = localStorage.getItem("dual-theme") || "dark";
    } catch (error) {
      theme = "dark";
    }
    if (theme !== "light") theme = "dark";

    function apply(next) {
      document.documentElement.setAttribute("data-theme", next);
      if (toggle) toggle.setAttribute("aria-pressed", next === "light" ? "true" : "false");
      if (meta) meta.setAttribute("content", next === "light" ? "#f7e8f0" : "#070208");
      try {
        localStorage.setItem("dual-theme", next);
      } catch (error) {
        return;
      }
    }

    apply(theme);

    if (toggle) {
      toggle.addEventListener("click", function () {
        apply(document.documentElement.getAttribute("data-theme") === "light" ? "dark" : "light");
      });
    }
  }

  function setupNav() {
    const toggle = $("[data-nav-toggle]");
    const nav = $("[data-nav]");
    if (!toggle || !nav) return;

    function setOpen(open) {
      document.body.classList.toggle("nav-open", open);
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
      toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    }

    toggle.addEventListener("click", function () {
      setOpen(!document.body.classList.contains("nav-open"));
    });

    $$("a", nav).forEach(function (link) {
      link.addEventListener("click", function () {
        setOpen(false);
      });
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") setOpen(false);
    });

    document.addEventListener("click", function (event) {
      if (!document.body.classList.contains("nav-open")) return;
      if (nav.contains(event.target) || toggle.contains(event.target)) return;
      setOpen(false);
    });
  }

  function setupHeader() {
    const header = $("[data-header]");
    if (!header) return;
    let ticking = false;

    function update() {
      header.classList.toggle("is-scrolled", window.scrollY > 18);
      ticking = false;
    }

    window.addEventListener("scroll", function () {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(update);
    }, { passive: true });

    update();
  }

  function setupParallax() {
    if (reduceMotion.matches || !finePointer.matches) return;
    let frame = 0;
    let targetX = 0;
    let targetY = 0;

    function apply() {
      document.documentElement.style.setProperty("--mx", targetX.toFixed(3));
      document.documentElement.style.setProperty("--my", targetY.toFixed(3));
      frame = 0;
    }

    window.addEventListener("pointermove", function (event) {
      targetX = (event.clientX / window.innerWidth - 0.5) * 2;
      targetY = (event.clientY / window.innerHeight - 0.5) * 2;
      if (!frame) frame = window.requestAnimationFrame(apply);
    }, { passive: true });
  }

  function setupTilt() {
    if (reduceMotion.matches || !finePointer.matches) return;
    $$("[data-tilt]").forEach(function (panel) {
      let frame = 0;
      let rx = 0;
      let ry = 0;

      function apply() {
        panel.style.transform = "perspective(1000px) rotateX(" + rx.toFixed(2) + "deg) rotateY(" + ry.toFixed(2) + "deg) translateY(-4px)";
        frame = 0;
      }

      panel.addEventListener("pointermove", function (event) {
        const rect = panel.getBoundingClientRect();
        const x = (event.clientX - rect.left) / rect.width - 0.5;
        const y = (event.clientY - rect.top) / rect.height - 0.5;
        ry = x * 5.5;
        rx = y * -4.5;
        if (!frame) frame = window.requestAnimationFrame(apply);
      });

      panel.addEventListener("pointerleave", function () {
        panel.style.transform = "";
        rx = 0;
        ry = 0;
      });
    });
  }

  function setupMusicDialog() {
    const dialog = $("[data-music-dialog]");
    const frameRoot = $("[data-music-dialog-frame]");
    const titleNode = $("[data-music-dialog-title]");
    const providerNode = $("[data-music-dialog-provider]");
    const noteNode = $("[data-music-dialog-note]");
    if (!dialog || !frameRoot) return;

    function clearFrame() {
      frameRoot.innerHTML = "";
      frameRoot.className = "music-dialog__frame";
    }

    function open(key) {
      const profile = config.profiles[key];
      if (!profile) return;
      const music = profile.music;
      clearFrame();

      if (titleNode) titleNode.textContent = music.title + " — " + music.artist;
      if (providerNode) providerNode.textContent = music.providerLabel || "official player";

      let iframe = null;
      if (music.provider === "youtube" && music.youtubeId) {
        frameRoot.classList.add("music-dialog__frame--video");
        iframe = document.createElement("iframe");
        iframe.src = "https://www.youtube-nocookie.com/embed/" + encodeURIComponent(music.youtubeId) + "?autoplay=1&rel=0&modestbranding=1";
        iframe.title = music.title + " — " + music.artist;
        iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share";
        iframe.allowFullscreen = true;
      } else if (music.provider === "spotify" && music.embedUrl) {
        frameRoot.classList.add("music-dialog__frame--spotify");
        iframe = document.createElement("iframe");
        iframe.src = music.embedUrl;
        iframe.title = music.title + " — " + music.artist;
        iframe.allow = "autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture";
        iframe.allowFullscreen = true;
        iframe.referrerPolicy = "strict-origin-when-cross-origin";
      } else if (music.embedUrl) {
        frameRoot.classList.add("music-dialog__frame--audiomack");
        iframe = document.createElement("iframe");
        const embedUrl = new URL(music.embedUrl);
        if (music.autoplay) embedUrl.searchParams.set("autoplay", "1");
        embedUrl.searchParams.set("_dual", String(Date.now()));
        iframe.src = embedUrl.toString();
        iframe.title = music.title + " — " + music.artist;
        iframe.allow = "autoplay; encrypted-media; fullscreen; picture-in-picture";
        iframe.setAttribute("scrolling", "no");
        iframe.referrerPolicy = "strict-origin-when-cross-origin";
      }

      if (iframe) {
        iframe.loading = "eager";
        frameRoot.appendChild(iframe);
      }

      if (noteNode) {
        noteNode.innerHTML = escapeHtml(music.hint || "The player loads from the official source.") +
          ' <a href="' + escapeHtml(music.sourceUrl || "#") + '" target="_blank" rel="noopener noreferrer">Open source</a>';
      }

      if (typeof dialog.showModal === "function") {
        if (!dialog.open) dialog.showModal();
      } else {
        dialog.setAttribute("open", "");
      }
    }

    function close() {
      if (typeof dialog.close === "function" && dialog.open) {
        dialog.close();
      } else {
        dialog.removeAttribute("open");
        clearFrame();
      }
    }

    $$("[data-music-open]").forEach(function (button) {
      button.addEventListener("click", function () {
        open(button.getAttribute("data-music-open"));
      });
    });

    $$("[data-music-close]").forEach(function (button) {
      button.addEventListener("click", close);
    });

    dialog.addEventListener("close", clearFrame);
    dialog.addEventListener("cancel", function () {
      clearFrame();
    });
    dialog.addEventListener("click", function (event) {
      if (event.target === dialog) close();
    });
  }

  function init() {
    document.documentElement.classList.remove("no-js");
    setupTheme();
    setupNav();
    setupHeader();
    setupParallax();
    setupTilt();
    setupMusicDialog();
    createStars();
    createPetals();

    Object.keys(config.profiles).forEach(function (key) {
      renderLinks(key);
      renderMusicCard(key);
      const state = discord ? discord.getState(key) : { phase: "loading", data: null };
      states[key] = state;
      renderProfile(key, state);
    });
    renderLove();
    renderNowbar();

    if (discord) {
      discord.on("presence", function (detail) {
        states[detail.key] = detail.state;
        renderProfile(detail.key, detail.state);
        renderLove();
        renderNowbar();
      });
      discord.on("connection", function () {
        renderLove();
      });
      discord.init();
    }

    window.setInterval(updateSpotifyProgress, 1000);
    reduceMotion.addEventListener("change", function () {
      if (reduceMotion.matches) {
        document.documentElement.style.setProperty("--mx", "0");
        document.documentElement.style.setProperty("--my", "0");
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
