(function () {
  "use strict";

  window.COUPLE_CONFIG = {
    site: {
      name: "DUAL",
      tagline: "Two worlds. One frequency.",
      description: "A private archive for two. Real-time Discord presence, live Spotify activity, and two personal soundtracks.",
      locale: "en-GB",
      since: null,
      lanyardInvite: "https://discord.gg/lanyard",
      ogImage: "assets/images/og-cover.png",
      favicon: "assets/icons/favicon.svg"
    },

    lanyard: {
      apiBase: "https://api.lanyard.rest/v1",
      socketUrl: "wss://api.lanyard.rest/socket",
      reconnectBaseMs: 1200,
      reconnectMaxMs: 30000,
      restRefreshMs: 300000,
      unavailableRetryMs: 300000
    },

    profiles: {
      me: {
        key: "me",
        discordId: "917462644624097352",
        page: "me.html",
        theme: "dark",
        accent: "#f4f4f5",
        fallbackName: "vezo",
        fallbackUsername: "v3z0lim",
        bio: "Even silence has a frequency.",
        avatarFallback: "assets/images/avatar-me-reference.png",
        banner: "assets/images/banner-me-reference.png",
        bannerFallback: "assets/images/banner-me-reference.png",
        links: [
          {
            label: "Discord",
            url: "https://discord.com/users/917462644624097352"
          },
          {
            label: "Audiomack",
            url: "https://audiomack.com/v3z0lim/song/zigzag"
          }
        ],
        music: {
          enabled: true,
          provider: "audiomack",
          title: "ZIGZAG",
          subtitle: "prod. DJ Problematic",
          artist: "vezo",
          album: "Single",
          artwork: "assets/images/cover-zigzag-reference.png",
          artworkFallback: "assets/images/cover-zigzag-reference.png",
          durationLabel: "2:11",
          sourceUrl: "https://audiomack.com/v3z0lim/song/zigzag",
          embedUrl: "https://audiomack.com/embed/v3z0lim/song/zigzag",
          autoplay: true,
          loop: false,
          volume: 0.55,
          providerLabel: "AUDIOMACK · OFFICIAL EMBED",
          hint: "Press play inside the Audiomack player. If autoplay is blocked, the player's own play button still works."
        }
      },

      her: {
        key: "her",
        discordId: "1445520612972957856",
        page: "her.html",
        theme: "romantic",
        accent: "#ff5c9d",
        fallbackName: "Her",
        fallbackUsername: "",
        bio: "Some songs are remembered by a name.",
        avatarFallback: "assets/images/avatar-her-reference.png",
        banner: "assets/images/banner-her-reference.png",
        bannerFallback: "assets/images/banner-her-reference.png",
        links: [
          {
            label: "Discord",
            url: "https://discord.com/users/1445520612972957856"
          },
          {
            label: "Lanyard",
            url: "https://discord.gg/lanyard"
          }
        ],
        note: "Staying on the same frequency as you is the quietest revolution in the world.",
        music: {
          enabled: true,
          provider: "spotify",
          title: "Matilda",
          subtitle: "Harry's House",
          artist: "Harry Styles",
          album: "Harry's House",
          artwork: "assets/images/cover-matilda-reference.png",
          artworkFallback: "assets/images/cover-matilda-reference.png",
          durationLabel: "4:02",
          sourceUrl: "https://open.spotify.com/track/6uvh0In7u1Xn4HgxOfAn8O",
          spotifyUrl: "https://open.spotify.com/track/6uvh0In7u1Xn4HgxOfAn8O",
          spotifyTrackId: "6uvh0In7u1Xn4HgxOfAn8O",
          embedUrl: "https://open.spotify.com/embed/track/6uvh0In7u1Xn4HgxOfAn8O?utm_source=generator&theme=0&locale=en",
          autoplay: true,
          loop: false,
          volume: 0.45,
          providerLabel: "SPOTIFY · OFFICIAL EMBED",
          hint: "Press play inside the Spotify player. Full playback may require signing in to Spotify; the preview works without an account."
        }
      }
    }
  };
})();
