# DUAL

A private, static digital archive for two. The site now has a neon dashboard home page, two profile pages, and a 404 page. Discord presence comes from Lanyard, Spotify activity comes from Lanyard presence data, and each profile has its own soundtrack.

## Pages

- `index.html`: dark neon dashboard with a central love stage, two live profile panels, theme toggle, music modal, and now-playing bars.
- `me.html`: dark monochrome profile page; live presence, platforms, Discord ID, and the Audiomack player.
- `her.html`: pink romantic profile page; Lanyard empty state, Spotify source, and the Spotify player.
- `404.html`: signal-lost page.

## Local development

There is no build step. Open the site through an HTTP server so the Spotify and Audiomack embeds and browser security rules work:

```powershell
cd C:\Users\omers\couple-website
python -m http.server 4173
```

Then open `http://localhost:4173`. The third-party music players may not work when the site is opened with `file://`.

## Configuration

All settings live in the `window.COUPLE_CONFIG` object inside `js/config.js`.

- `site.since`: leave as `null` to hide the together-since counter. Use an ISO date such as `"2024-02-14"` to enable it.
- `site.lanyardInvite`: Lanyard invite link.
- `profiles.me` / `profiles.her`: Discord ID, page, theme, fallback name/username, bio, avatar, banner, links, and music settings.
- `profiles.*.fallbackName`: name shown when Lanyard data is unavailable. `her` currently uses `Her`; change it when the real name is known.
- `profiles.*.links`: external links shown in profile panels and the links section.
- `profiles.*.music`: provider, title, artist, artwork, source URL, autoplay, loop, and volume.

## Lanyard setup

Lanyard exposes Discord presence through a public API. The site never uses a Discord token.

1. Join `https://discord.gg/lanyard` with the relevant Discord account.
2. Put the Discord ID in the correct profile inside `config.js`.
3. Reload the page. If the account is in the server, status, custom status, platforms, and Spotify activity arrive automatically.

Notes:

- If an account is not in the Lanyard server, the API returns `404`. The site does not invent data; it shows the "Waiting for Lanyard" state and the invite link.
- Lanyard does not provide bios. Bios come from the `bio` field in `config.js`.
- Presence data is public. Manage your privacy preferences through Discord.
- The `her` profile currently returns `404`; the panel will fill in automatically once the account joins the Lanyard server.

## Music

### vezo — Audiomack

- Uses the official Audiomack embed: `https://audiomack.com/embed/v3z0lim/song/zigzag`.
- Adds `autoplay=1`; if the browser blocks autoplay, use the player's own play button.
- The embed is third-party, so the page's custom volume, mute, and seek controls are disabled. Playback and volume are managed inside the Audiomack player. The round button reloads the embed to try starting it again.

### Her — Spotify

- Official Harry Styles "Matilda" track: `https://open.spotify.com/track/6uvh0In7u1Xn4HgxOfAn8O`.
- Uses the official Spotify embed: `https://open.spotify.com/embed/track/6uvh0In7u1Xn4HgxOfAn8O`.
- Playback is controlled inside the Spotify player. Full playback may require signing in to Spotify; the preview works without an account.
- If autoplay is blocked, press play inside the Spotify player. The source link opens the track on Spotify.
- The Spotify player must be loaded over HTTP/HTTPS. Use `python -m http.server` for local testing.

Both soundtracks are independent of Discord Spotify activity.

## Visuals

The SVG/PNG files under `assets/` are placeholders and can be replaced with your own photos or covers.

- `assets/banners/`: profile page and card banners.
- `assets/images/`: avatars, covers, and `og-cover.png`.
- `assets/icons/favicon.svg`: site icon.

`og-cover.png` is 1200×630. For social previews, set your deployed absolute URL in the `og:image` fields in `index.html`, `me.html`, `her.html`, and `404.html`.

## Deploying to Vercel

1. Put this folder in a Git repository or upload it directly to Vercel.
2. Framework preset: **Other**. No build command or output directory is required.
3. `vercel.json` enables clean URLs. Vercel uses `404.html` as the custom 404 page.
4. No environment variables or secrets are required.

## Test

```powershell
node --check js/config.js
node --check js/discord.js
node --check js/music.js
node --check js/main.js
node --check js/dashboard.js
```

Check in the browser:

- Lanyard connection and `data-live-state` badges.
- Spotify progress bar and elapsed-time counter when activity arrives.
- The "Waiting for Lanyard" empty state and invite link for `her`.
- Audiomack embed loading and playback after pressing the player's play button.
- Spotify embed loading, preview playback, and the sign-in requirement for full tracks.
- Mobile menu, page transitions, `prefers-reduced-motion`, light theme, and the 380–1440 px range.

## Tech

- HTML5, CSS3, vanilla JavaScript
- Lanyard REST + WebSocket
- Spotify activity via Lanyard presence
- Official Audiomack embed
- Official Spotify embed
- YouTube IFrame Player API (optional provider)
- Google Fonts: Manrope, Cormorant Garamond, JetBrains Mono

## Credits

- [Lanyard](https://github.com/Phineas/lanyard) — Discord presence API.
- Spotify, Audiomack, and YouTube — media sources.
- Google Fonts — typography.
