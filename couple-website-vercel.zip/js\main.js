(function () {
  "use strict";

  const config = window.COUPLE_CONFIG;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const finePointer = window.matchMedia("(pointer: fine)");
  const desktopQuery = window.matchMedia("(min-width: 821px)");

  const statusLabels = {
    online: "Online",
    idle: "Idle",
    dnd: "Do not disturb",
    offline: "Offline"
  };

  const platformLabels = {
    desktop: "Desktop",
    mobile: "Mobile",
    web: "Web",
    embedded: "Embedded",
    vr: "VR"
  };

  const activityLabels = {
    0: "Playing",
    1: "Streaming",
    2: "Listening",
    3: "Watching",
    5: "Competing"
  };

  const connectionLabels = {
    idle: "Ready",
    connecting: "Connecting",
    live: "Live",
    reconnecting: "Reconnecting",
    offline: "Offline"
  };

  const iconPaths = {
    "arrow-up-right": '<path d="M7 17 17 7M8 7h9v9"></path>',
    "arrow-right": '<path d="M5 12h14M13 6l6 6-6 6"></path>',
    "arrow-left": '<path d="M19 12H5M11 18l-6-6 6-6"></path>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"></path>',
    close: '<path d="M6 6l12 12M18 6 6 18"></path>',
    play: '<path d="M8 5v14l11-7z" fill="currentColor" stroke="none"></path>',
    pause: '<path d="M8 5v14M16 5v14"></path>',
    volume: '<path d="M11 5 6 9H3v6h3l5 4V5Z"></path><path d="M15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12"></path>',
    "volume-off": '<path d="M11 5 6 9H3v6h3l5 4V5Z"></path><path d="m16 9 5 6M21 9l-5 6"></path>',
    spotify: '<circle cx="12" cy="12" r="9"></circle><path d="M7.5 9.5c3.5-1 7-.5 9.5 1M8 12.5c2.8-.8 5.6-.4 7.6.8M8.5 15.4c2.2-.6 4.4-.3 6 .6"></path>',
    youtube: '<rect x="3" y="6" width="18" height="12" rx="3"></rect><path d="m10 9 5 3-5 3z" fill="currentColor" stroke="none"></path>',
    discord: '<path d="M21 12a8 8 0 0 1-8 8H6l-3 2 1-4a8 8 0 1 1 17-6Z"></path><path d="M9 12h.01M15 12h.01"></path>',
    music: '<path d="M9 18V5l10-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="16" cy="16" r="3"></circle>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"></path>',
    signal: '<path d="M5 12a10 10 0 0 1 14 0M8.5 15.5a5 5 0 0 1 7 0M12 19h.01"></path>',
    clock: '<circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3 2"></path>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="3"></rect><path d="M8 3v4M16 3v4M3 10h18"></path>',
    id: '<rect x="3" y="5" width="18" height="14" rx="3"></rect><circle cx="8.5" cy="11" r="2"></circle><path d="M5.5 16c.5-1.5 1.5-2.2 3-2.2s2.5.7 3 2.2M14 10h4M14 14h4"></path>',
    link: '<path d="M10 13a5 5 0 0 0 7 0l2-2a5 5 0 0 0-7-7l-1 1"></path><path d="M14 11a5 5 0 0 0-7 0l-2 2a5 5 0 0 0 7 7l1-1"></path>',
    sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"></path><path d="M19 16l.7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z"></path>',
    headphones: '<path d="M4 14v-2a8 8 0 0 1 16 0v2"></path><rect x="3" y="13" width="4" height="7" rx="2"></rect><rect x="17" y="13" width="4" height="7" rx="2"></rect>',
    "chevron-down": '<path d="m6 9 6 6 6-6"></path>',
    check: '<path d="m5 12 4 4L19 6"></path>',
    alert: '<path d="M12 3 2 21h20L12 3Z"></path><path d="M12 9v5M12 18h.01"></path>',
    moon: '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4 8.5 8.5 0 1 0 20 14.5Z"></path>',
    wave: '<path d="M2 12h3l2-6 4 12 3-9 2 3h6"></path>',
    gamepad: '<path d="M7 12h2M8 11v2M16 12h.01M18 10h.01"></path><rect x="2" y="7" width="20" height="10" rx="5"></rect>',
    copy: '<rect x="9" y="9" width="12" height="12" rx="2"></rect><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"></path>',
    share: '<circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"></path>'
  };

  let toastTimer = null;

  function renderIcon(span) {
    if (!span || span.dataset.iconReady === "true") return;
    const name = span.dataset.icon;
    const path = iconPaths[name];
    if (!path) return;
    span.innerHTML = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + path + "</svg>";
    span.dataset.iconReady = "true";
  }

  function hydrateIcons(root) {
    if (!root) return;
    if (root.matches && root.matches("[data-icon]")) renderIcon(root);
    if (!root.querySelectorAll) return;
    root.querySelectorAll("[data-icon]").forEach(renderIcon);
  }

  function makeIcon(name) {
    const span = document.createElement("span");
    span.dataset.icon = name;
    return span;
  }

  function el(tag, className, value) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (value !== undefined && value !== null) node.textContent = String(value);
    return node;
  }

  function setTextAll(root, selector, value) {
    root.querySelectorAll(selector).forEach((node) => {
      node.textContent = value;
    });
  }

  function safeUrl(value) {
    if (!value) return null;
    try {
      const url = new URL(value, window.location.href);
      if (url.protocol !== "http:" && url.protocol !== "https:") return null;
      return url.href;
    } catch (error) {
      return null;
    }
  }

  function formatDuration(value) {
    const seconds = Number(value);
    if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
    const total = Math.floor(seconds);
    return Math.floor(total / 60) + ":" + String(total % 60).padStart(2, "0");
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function setImage(img, src, fallback) {
    if (!img) return;
    const next = src || fallback;
    if (!next) return;
    if (img.dataset.attemptedSrc === next && img.dataset.fallbackApplied === "true") return;
    img.dataset.fallback = fallback || "";
    img.dataset.attemptedSrc = next;
    delete img.dataset.fallbackApplied;
    if (img.getAttribute("src") !== next) img.src = next;
  }

  function showToast(message) {
    let toast = document.querySelector("[data-toast]");
    if (!toast) {
      toast = el("div", "toast");
      toast.dataset.toast = "";
      toast.setAttribute("role", "status");
      toast.setAttribute("aria-live", "polite");
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 2000);
  }

  async function copyText(value) {
    if (!value) return false;
    try {
      await navigator.clipboard.writeText(value);
      return true;
    } catch (error) {}
    const area = document.createElement("textarea");
    area.value = value;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.opacity = "0";
    area.style.pointerEvents = "none";
    document.body.appendChild(area);
    area.select();
    let copied = false;
    try {
      copied = document.execCommand("copy");
    } catch (error) {
      copied = false;
    }
    area.remove();
    return copied;
  }

  function parseSince(value) {
    if (!value) return null;
    const text = String(value);
    const date = /^\d{4}-\d{2}-\d{2}$/.test(text) ? new Date(text + "T00:00:00") : new Date(text);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function linkIcon(label) {
    const key = String(label || "").toLowerCase();
    if (key.includes("discord")) return "discord";
    if (key.includes("audiomack") || key.includes("spotify")) return "music";
    if (key.includes("lanyard")) return "signal";
    return "link";
  }

  function renderProfileLinks(root, profile) {
    root.querySelectorAll("[data-profile-links]").forEach((container) => {
      container.replaceChildren();
      (profile.links || []).forEach((link) => {
        const href = safeUrl(link.url);
        if (!href) return;
        const anchor = el("a", "profile-link");
        anchor.href = href;
        anchor.target = "_blank";
        anchor.rel = "noopener noreferrer";
        anchor.setAttribute("aria-label", link.label + " · opens in a new tab");
        anchor.appendChild(makeIcon(linkIcon(link.label)));
        anchor.appendChild(el("span", "profile-link__label", link.label));
        anchor.appendChild(makeIcon("arrow-up-right"));
        container.appendChild(anchor);
      });
      container.hidden = container.children.length === 0;
      hydrateIcons(container);
    });
  }

  function initProfileMeta(root) {
    const key = root.dataset.profile;
    const profile = config.profiles[key];
    if (!profile) return;
    root.querySelectorAll("[data-profile-bio]").forEach((node) => {
      node.textContent = profile.bio || "";
    });
    root.querySelectorAll("[data-profile-note]").forEach((node) => {
      node.textContent = profile.note || "";
    });
    root.querySelectorAll("[data-profile-id]").forEach((node) => {
      node.textContent = profile.discordId;
    });
    root.querySelectorAll("[data-copy-profile-id]").forEach((button) => {
      button.dataset.copy = profile.discordId;
    });
    root.querySelectorAll("[data-profile-discord]").forEach((anchor) => {
      anchor.href = "https://discord.com/users/" + profile.discordId;
    });
    root.querySelectorAll("[data-profile-page-link]").forEach((anchor) => {
      anchor.href = profile.page;
    });
    root.querySelectorAll("[data-profile-source-link]").forEach((anchor) => {
      if (profile.music && profile.music.sourceUrl) {
        anchor.href = profile.music.sourceUrl;
        anchor.hidden = false;
      } else {
        anchor.hidden = true;
      }
    });
    renderProfileLinks(root, profile);
  }

  function renderCustomStatus(root, data) {
    const custom = data && data.customStatus ? data.customStatus : null;
    const stateText = custom && custom.state ? custom.state : "";
    const emoji = custom && custom.emoji ? custom.emoji : null;
    root.querySelectorAll("[data-profile-custom]").forEach((container) => {
      container.replaceChildren();
      if (!stateText && !emoji) {
        container.hidden = true;
        return;
      }
      container.hidden = false;
      if (emoji) {
        if (emoji.id) {
          const img = el("img", "custom-status__emoji");
          img.src = "https://cdn.discordapp.com/emojis/" + emoji.id + "." + (emoji.animated ? "gif" : "png") + "?size=32";
          img.alt = emoji.name || "emoji";
          img.loading = "lazy";
          container.appendChild(img);
        } else if (emoji.name) {
          container.appendChild(el("span", "custom-status__emoji", emoji.name));
        }
      }
      if (stateText) container.appendChild(el("span", "custom-status__text", stateText));
    });
  }

  function renderPlatforms(root, data) {
    const active = [];
    if (data && data.platforms) {
      Object.keys(data.platforms).forEach((key) => {
        if (data.platforms[key]) active.push(platformLabels[key] || key);
      });
    }
    root.querySelectorAll("[data-profile-platforms]").forEach((container) => {
      container.replaceChildren();
      active.forEach((label) => {
        container.appendChild(el("span", "platform-chip", label));
      });
      container.hidden = active.length === 0;
    });
  }

  function emptyState(title, message, iconName) {
    const box = el("div", "now-empty");
    const icon = el("span", "now-empty__icon");
    icon.appendChild(makeIcon(iconName || "wave"));
    box.appendChild(icon);
    box.appendChild(el("p", "now-empty__title", title));
    box.appendChild(el("p", "now-empty__text", message));
    hydrateIcons(box);
    return box;
  }

  function notConnectedState() {
    const box = el("div", "now-empty now-empty--signal");
    const icon = el("span", "now-empty__icon");
    icon.appendChild(makeIcon("signal"));
    box.appendChild(icon);
    box.appendChild(el("span", "now-empty__eyebrow", "LANYARD · NO SIGNAL"));
    box.appendChild(el("p", "now-empty__title", "Waiting for Lanyard"));
    box.appendChild(el("p", "now-empty__text", "This account has not joined the Lanyard server. Once it does, Discord presence and Spotify activity will appear here live."));
    const invite = safeUrl(config.site.lanyardInvite);
    if (invite) {
      const link = el("a", "btn btn--ghost btn--sm now-empty__action");
      link.href = invite;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.appendChild(el("span", "", "Join Lanyard"));
      link.appendChild(makeIcon("arrow-up-right"));
      box.appendChild(link);
    }
    hydrateIcons(box);
    return box;
  }

  function errorState(key) {
    const box = el("div", "now-empty now-empty--error");
    const icon = el("span", "now-empty__icon");
    icon.appendChild(makeIcon("alert"));
    box.appendChild(icon);
    box.appendChild(el("p", "now-empty__title", "Status unavailable"));
    box.appendChild(el("p", "now-empty__text", "Lanyard cannot be reached right now. Try again when the connection returns."));
    const button = el("button", "btn btn--ghost btn--sm now-empty__action");
    button.type = "button";
    button.dataset.discordRetry = key;
    button.appendChild(el("span", "", "Try again"));
    button.appendChild(makeIcon("arrow-right"));
    box.appendChild(button);
    hydrateIcons(box);
    return box;
  }

  function skeletonState() {
    const box = el("div", "now-skeleton");
    box.setAttribute("role", "status");
    box.setAttribute("aria-label", "Loading status");
    box.appendChild(el("span", "now-skeleton__media"));
    const lines = el("div", "now-skeleton__lines");
    lines.appendChild(el("span", "now-skeleton__line now-skeleton__line--short"));
    lines.appendChild(el("span", "now-skeleton__line"));
    lines.appendChild(el("span", "now-skeleton__line now-skeleton__line--medium"));
    box.appendChild(lines);
    return box;
  }

  function equalizer(className) {
    const box = el("span", className || "equalizer");
    box.setAttribute("aria-hidden", "true");
    for (let index = 0; index < 4; index += 1) {
      box.appendChild(el("i"));
    }
    return box;
  }

  function spotifyCard(spotify, profile) {
    const start = spotify.timestamps && Number(spotify.timestamps.start) ? Number(spotify.timestamps.start) : 0;
    const end = spotify.timestamps && Number(spotify.timestamps.end) ? Number(spotify.timestamps.end) : 0;
    const card = el("div", "now-card now-card--spotify");
    card.dataset.spotifyCard = "";
    card.dataset.start = String(start);
    card.dataset.end = String(end);

    const media = el("div", "now-card__media");
    const img = el("img", "now-card__art");
    img.src = spotify.album_art_url || "assets/images/cover-spotify.svg";
    img.alt = spotify.album ? spotify.album + " cover art" : "Spotify cover art";
    img.loading = "lazy";
    img.dataset.fallback = "assets/images/cover-spotify.svg";
    media.appendChild(img);
    media.appendChild(equalizer("equalizer equalizer--card"));

    const body = el("div", "now-card__body");
    const eyebrow = el("span", "now-card__eyebrow");
    eyebrow.appendChild(makeIcon("spotify"));
    eyebrow.appendChild(el("span", "", "Spotify · now"));
    body.appendChild(eyebrow);

    const trackUrl = spotify.track_id ? "https://open.spotify.com/track/" + encodeURIComponent(spotify.track_id) : (profile.music && profile.music.sourceUrl);
    const href = safeUrl(trackUrl);
    const title = href ? el("a", "now-card__title") : el("p", "now-card__title");
    title.textContent = spotify.song || "Unknown track";
    if (href) {
      title.href = href;
      title.target = "_blank";
      title.rel = "noopener noreferrer";
    }
    body.appendChild(title);

    const artistName = spotify.artist || (Array.isArray(spotify.artists) ? spotify.artists.map((artist) => artist.name).filter(Boolean).join(", ") : "");
    const meta = [artistName, spotify.album].filter(Boolean).join(" · ");
    body.appendChild(el("p", "now-card__artist", meta || "Spotify"));

    const progress = el("div", "now-card__progress");
    progress.setAttribute("aria-hidden", "true");
    const fill = el("span", "now-card__progress-fill");
    fill.dataset.spotifyProgress = "";
    progress.appendChild(fill);
    const time = el("div", "now-card__time");
    const elapsed = el("span", "", "0:00");
    elapsed.dataset.spotifyElapsed = "";
    const duration = el("span", "", "0:00");
    duration.dataset.spotifyDuration = "";
    time.appendChild(elapsed);
    time.appendChild(duration);
    body.appendChild(progress);
    body.appendChild(time);
    if (!start || !end || end <= start) {
      progress.hidden = true;
      time.hidden = true;
    }

    card.appendChild(media);
    card.appendChild(body);
    hydrateIcons(card);
    return card;
  }

  function activityImage(activity) {
    const assets = activity && activity.assets ? activity.assets : null;
    const image = assets && assets.large_image ? String(assets.large_image) : "";
    if (!image) return null;
    if (image.startsWith("https://") || image.startsWith("http://")) return image;
    if (image.startsWith("spotify:image:")) return "https://i.scdn.co/image/" + image.slice("spotify:image:".length);
    if (activity.application_id && !image.includes(":")) {
      return "https://cdn.discordapp.com/app-assets/" + activity.application_id + "/" + image + ".png";
    }
    return null;
  }

  function activityCard(activity) {
    const card = el("div", "now-card now-card--activity");
    const media = el("div", "now-card__media now-card__media--activity");
    const image = safeUrl(activityImage(activity));
    if (image) {
      const img = el("img", "now-card__art");
      img.src = image;
      img.alt = activity.name ? activity.name + " activity image" : "Activity image";
      img.loading = "lazy";
      img.dataset.fallback = "assets/images/cover-spotify.svg";
      media.appendChild(img);
    } else {
      media.appendChild(makeIcon("gamepad"));
    }

    const body = el("div", "now-card__body");
    const type = Number(activity.type);
    body.appendChild(el("span", "now-card__eyebrow", activityLabels[type] || "Activity"));
    body.appendChild(el("p", "now-card__title", activity.name || "Unknown activity"));
    const details = [activity.details, activity.state].filter(Boolean).join(" · ");
    body.appendChild(el("p", "now-card__artist", details || "Discord activity"));

    card.appendChild(media);
    card.appendChild(body);
    hydrateIcons(card);
    return card;
  }

  function renderActivity(root, key, state) {
    root.querySelectorAll("[data-profile-activity]").forEach((container) => {
      container.replaceChildren();
      container.dataset.phase = state.phase;
      if (state.phase === "loading") {
        container.appendChild(skeletonState());
        return;
      }
      if (state.phase === "not_connected") {
        container.appendChild(notConnectedState());
        return;
      }
      if (state.phase === "error") {
        container.appendChild(errorState(key));
        return;
      }
      const data = state.data;
      if (!data) {
        container.appendChild(emptyState("Quiet mode", "No activity right now.", "wave"));
        return;
      }
      if (data.spotify) {
        container.appendChild(spotifyCard(data.spotify, config.profiles[key]));
        return;
      }
      const activities = (data.activities || []).filter((activity) => Number(activity.type) !== 4);
      if (activities.length) {
        activities.slice(0, 2).forEach((activity) => {
          container.appendChild(activityCard(activity));
        });
        return;
      }
      if (data.status === "offline") {
        container.appendChild(emptyState("Offline right now", "This space will come alive when the signal returns.", "moon"));
      } else {
        container.appendChild(emptyState("Quiet mode", "No activity right now.", "wave"));
      }
    });
  }

  function renderProfile(root) {
    const key = root.dataset.profile;
    const profile = config.profiles[key];
    if (!profile) return;
    const state = window.CoupleDiscord ? window.CoupleDiscord.getState(key) : {
      phase: "error",
      data: null,
      error: { message: "Discord module failed to load." }
    };
    const data = state.data;
    const user = data ? data.user : null;
    root.dataset.phase = state.phase;

    const name = user && user.displayName ? user.displayName : profile.fallbackName;
    let handle = "";
    if (user && user.username) handle = "@" + user.username;
    else if (profile.fallbackUsername) handle = "@" + profile.fallbackUsername;
    else if (state.phase === "not_connected") handle = "waiting for Lanyard";
    else if (state.phase === "loading") handle = "connecting";
    else if (state.phase === "error") handle = "connection error";
    else handle = "discord";

    let statusKey = "unknown";
    let statusText = "No signal";
    if (state.phase === "ready" && data) {
      statusKey = data.status || "offline";
      statusText = statusLabels[statusKey] || "Unknown";
    } else if (state.phase === "loading") {
      statusKey = "loading";
      statusText = "Connecting";
    } else if (state.phase === "not_connected") {
      statusKey = "unknown";
      statusText = "Waiting for Lanyard";
    } else if (state.phase === "error") {
      statusKey = "error";
      statusText = "Connection error";
    }

    setTextAll(root, "[data-profile-name]", name);
    setTextAll(root, "[data-profile-username]", handle);
    setTextAll(root, "[data-profile-status]", statusText);
    root.querySelectorAll("[data-profile-status-dot]").forEach((dot) => {
      dot.dataset.status = statusKey;
    });

    const avatar = user && user.avatarUrl ? user.avatarUrl : profile.avatarFallback;
    root.querySelectorAll("[data-profile-avatar]").forEach((img) => {
      setImage(img, avatar, profile.avatarFallback);
    });

    renderCustomStatus(root, data);
    renderPlatforms(root, data);
    renderActivity(root, key, state);
  }

  function renderConnection(status) {
    document.querySelectorAll("[data-live-state]").forEach((badge) => {
      badge.dataset.state = status;
      const label = badge.querySelector("[data-live-state-text]");
      if (label) label.textContent = connectionLabels[status] || "Ready";
    });
  }

  function initDiscord() {
    const roots = document.querySelectorAll("[data-profile]");
    roots.forEach(initProfileMeta);
    roots.forEach(renderProfile);
    if (!window.CoupleDiscord) {
      renderConnection("offline");
      return;
    }
    window.CoupleDiscord.on("presence", (event) => {
      document.querySelectorAll('[data-profile="' + event.key + '"]').forEach(renderProfile);
    });
    window.CoupleDiscord.on("connection", (event) => {
      renderConnection(event.status);
    });
    window.CoupleDiscord.init();
    renderConnection(window.CoupleDiscord.getConnection());
  }

  function initMusic() {
    if (!window.CoupleMusic) return;
    document.querySelectorAll("[data-music]").forEach((root) => {
      const key = root.dataset.music;
      const profile = config.profiles[key];
      if (profile) window.CoupleMusic.create(root, profile);
    });
  }

  function initNav() {
    const header = document.querySelector("[data-header]");
    const toggle = document.querySelector("[data-nav-toggle]");
    const nav = document.querySelector("[data-nav]");
    let open = false;

    function setOpen(next) {
      open = Boolean(next);
      if (nav) nav.classList.toggle("is-open", open);
      if (toggle) {
        toggle.classList.toggle("is-active", open);
        toggle.setAttribute("aria-expanded", open ? "true" : "false");
        toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      }
      document.body.classList.toggle("nav-open", open);
    }

    if (toggle) {
      toggle.addEventListener("click", () => setOpen(!open));
    }
    if (nav) {
      nav.querySelectorAll("a").forEach((link) => {
        link.addEventListener("click", () => setOpen(false));
      });
    }
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && open) setOpen(false);
    });
    document.addEventListener("click", (event) => {
      if (!open) return;
      if (nav && nav.contains(event.target)) return;
      if (toggle && toggle.contains(event.target)) return;
      setOpen(false);
    });
    if (desktopQuery.addEventListener) {
      desktopQuery.addEventListener("change", (event) => {
        if (event.matches) setOpen(false);
      });
    }

    if (header) {
      const onScroll = () => {
        header.classList.toggle("is-scrolled", window.scrollY > 16);
      };
      onScroll();
      window.addEventListener("scroll", onScroll, { passive: true });
    }
  }

  function initPageTransitions() {
    document.documentElement.classList.remove("no-js");
    document.documentElement.classList.add("js");
    requestAnimationFrame(() => {
      document.body.classList.add("is-loaded");
    });

    let leaving = false;
    document.addEventListener("click", (event) => {
      if (leaving || event.defaultPrevented || event.button !== 0) return;
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const link = event.target.closest("a[href]");
      if (!link) return;
      if (link.hasAttribute("download")) return;
      if (link.dataset.noTransition === "true") return;
      if (link.target && link.target !== "_self") return;
      const href = link.getAttribute("href");
      if (!href || href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("tel:")) return;
      const url = new URL(href, window.location.href);
      if (url.origin !== window.location.origin) return;
      if (url.pathname === window.location.pathname) {
        if (!url.hash) event.preventDefault();
        return;
      }
      event.preventDefault();
      leaving = true;
      document.body.classList.add("is-leaving");
      const delay = reduceMotion.matches ? 0 : 220;
      setTimeout(() => {
        window.location.href = url.href;
      }, delay);
    });

    window.addEventListener("pageshow", () => {
      leaving = false;
      document.body.classList.remove("is-leaving");
      document.body.classList.add("is-loaded");
    });
  }

  function initReveal() {
    const items = Array.from(document.querySelectorAll("[data-reveal]"));
    if (!items.length) return;
    if (reduceMotion.matches || !("IntersectionObserver" in window)) {
      items.forEach((item) => item.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -8% 0px" });
    items.forEach((item, index) => {
      const delay = Number(item.dataset.revealDelay);
      item.style.setProperty("--reveal-delay", (Number.isFinite(delay) ? delay : Math.min(index * 45, 280)) + "ms");
      observer.observe(item);
    });
  }

  function initTilt() {
    if (reduceMotion.matches || !finePointer.matches) return;
    document.querySelectorAll("[data-tilt]").forEach((node) => {
      let frame = null;
      node.addEventListener("pointermove", (event) => {
        if (reduceMotion.matches) return;
        const rect = node.getBoundingClientRect();
        const x = (event.clientX - rect.left) / rect.width - 0.5;
        const y = (event.clientY - rect.top) / rect.height - 0.5;
        if (frame) cancelAnimationFrame(frame);
        frame = requestAnimationFrame(() => {
          node.style.setProperty("--tilt-y", (x * 6).toFixed(2) + "deg");
          node.style.setProperty("--tilt-x", (-y * 6).toFixed(2) + "deg");
        });
      });
      node.addEventListener("pointerleave", () => {
        if (frame) cancelAnimationFrame(frame);
        node.style.setProperty("--tilt-x", "0deg");
        node.style.setProperty("--tilt-y", "0deg");
      });
    });
  }

  function initSpotlight() {
    if (reduceMotion.matches || !finePointer.matches) return;
    document.querySelectorAll("[data-spotlight]").forEach((node) => {
      node.addEventListener("pointermove", (event) => {
        const rect = node.getBoundingClientRect();
        node.style.setProperty("--spot-x", ((event.clientX - rect.left) / rect.width) * 100 + "%");
        node.style.setProperty("--spot-y", ((event.clientY - rect.top) / rect.height) * 100 + "%");
      });
    });
  }

  function initClock() {
    const timeFormat = new Intl.DateTimeFormat(config.site.locale || "en-GB", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    });
    const dateFormat = new Intl.DateTimeFormat(config.site.locale || "en-GB", {
      day: "2-digit",
      month: "long",
      year: "numeric"
    });
    const timeNodes = document.querySelectorAll("[data-clock]");
    const dateNodes = document.querySelectorAll("[data-date]");
    if (!timeNodes.length && !dateNodes.length) return;
    const update = () => {
      const now = new Date();
      timeNodes.forEach((node) => {
        node.textContent = timeFormat.format(now);
      });
      dateNodes.forEach((node) => {
        node.textContent = dateFormat.format(now);
      });
    };
    update();
    setInterval(update, 1000);
  }

  function initSince() {
    const section = document.querySelector("[data-since-section]");
    const since = parseSince(config.site.since);
    if (!section || !since) {
      if (section) section.hidden = true;
      return;
    }
    section.hidden = false;
    const daysNode = section.querySelector("[data-since-days]");
    const hoursNode = section.querySelector("[data-since-hours]");
    const minutesNode = section.querySelector("[data-since-minutes]");
    const secondsNode = section.querySelector("[data-since-seconds]");
    const dateNode = section.querySelector("[data-since-date]");
    if (dateNode) {
      dateNode.textContent = new Intl.DateTimeFormat(config.site.locale || "en-GB", {
        day: "numeric",
        month: "long",
        year: "numeric"
      }).format(since);
    }
    const update = () => {
      const diff = Math.max(0, Date.now() - since.getTime());
      const days = Math.floor(diff / 86400000);
      const hours = Math.floor((diff % 86400000) / 3600000);
      const minutes = Math.floor((diff % 3600000) / 60000);
      const seconds = Math.floor((diff % 60000) / 1000);
      if (daysNode) daysNode.textContent = String(days);
      if (hoursNode) hoursNode.textContent = String(hours).padStart(2, "0");
      if (minutesNode) minutesNode.textContent = String(minutes).padStart(2, "0");
      if (secondsNode) secondsNode.textContent = String(seconds).padStart(2, "0");
    };
    update();
    setInterval(update, 1000);
  }

  function updateSpotifyCards() {
    document.querySelectorAll("[data-spotify-card]").forEach((card) => {
      const start = Number(card.dataset.start) || 0;
      const end = Number(card.dataset.end) || 0;
      const total = Math.max(0, end - start);
      const current = total ? clamp(Date.now() - start, 0, total) : 0;
      const percent = total ? (current / total) * 100 : 0;
      const fill = card.querySelector("[data-spotify-progress]");
      if (fill) fill.style.width = percent + "%";
      const elapsed = card.querySelector("[data-spotify-elapsed]");
      if (elapsed) elapsed.textContent = formatDuration(current / 1000);
      const duration = card.querySelector("[data-spotify-duration]");
      if (duration) duration.textContent = formatDuration(total / 1000);
    });
  }

  function initSpotifyTicker() {
    updateSpotifyCards();
    setInterval(updateSpotifyCards, 1000);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") updateSpotifyCards();
    });
  }

  function initImageFallback() {
    document.addEventListener("error", (event) => {
      const img = event.target;
      if (!(img instanceof HTMLImageElement)) return;
      const fallback = img.dataset.fallback;
      if (!fallback || img.dataset.fallbackApplied === "true") return;
      img.dataset.fallbackApplied = "true";
      img.src = fallback;
    }, true);
  }

  function initActions() {
    document.addEventListener("click", async (event) => {
      const retry = event.target.closest("[data-discord-retry]");
      if (retry) {
        event.preventDefault();
        if (!window.CoupleDiscord) return;
        retry.disabled = true;
        try {
          await window.CoupleDiscord.refresh(retry.dataset.discordRetry);
        } finally {
          retry.disabled = false;
        }
        return;
      }

      const copyButton = event.target.closest("[data-copy]");
      if (copyButton) {
        event.preventDefault();
        const copied = await copyText(copyButton.dataset.copy);
        if (copied) {
          copyButton.dataset.copied = "true";
          showToast("Copied");
          setTimeout(() => {
            delete copyButton.dataset.copied;
          }, 1600);
        } else {
          showToast("Could not copy");
        }
        return;
      }

      const shareButton = event.target.closest("[data-share]");
      if (shareButton) {
        event.preventDefault();
        const shareData = {
          title: document.title,
          text: config.site.tagline,
          url: window.location.href
        };
        if (navigator.share) {
          try {
            await navigator.share(shareData);
          } catch (error) {}
        } else {
          const copied = await copyText(shareData.url);
          showToast(copied ? "Link copied" : "Could not copy");
        }
      }
    });
  }

  function init() {
    hydrateIcons(document);
    initNav();
    initPageTransitions();
    initReveal();
    initTilt();
    initSpotlight();
    initClock();
    initSince();
    initSpotifyTicker();
    initImageFallback();
    initActions();
    initMusic();
    initDiscord();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
