(function () {
  "use strict";

  const players = new Set();
  let youtubeApiPromise = null;

  const iconPaths = {
    play: '<path d="M8 5v14l11-7z" fill="currentColor" stroke="none"></path>',
    pause: '<path d="M8 5v14M16 5v14"></path>',
    volume: '<path d="M11 5 6 9H3v6h3l5 4V5Z"></path><path d="M15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12"></path>',
    "volume-off": '<path d="M11 5 6 9H3v6h3l5 4V5Z"></path><path d="m16 9 5 6M21 9l-5 6"></path>'
  };

  function setIcon(element, name) {
    if (!element) return;
    const path = iconPaths[name] || iconPaths.play;
    element.innerHTML = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + path + "</svg>";
  }

  function formatTime(value) {
    const seconds = Number(value);
    if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
    const whole = Math.floor(seconds);
    const minutes = Math.floor(whole / 60);
    const rest = whole % 60;
    return minutes + ":" + String(rest).padStart(2, "0");
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function setRangeFill(input, percent) {
    if (!input) return;
    input.style.setProperty("--range-progress", clamp(percent, 0, 100) + "%");
  }

  function loadYouTubeApi() {
    if (window.YT && typeof window.YT.Player === "function") {
      return Promise.resolve(window.YT);
    }
    if (youtubeApiPromise) return youtubeApiPromise;

    youtubeApiPromise = new Promise(function (resolve, reject) {
      const previousReady = window.onYouTubeIframeAPIReady;
      let settled = false;
      const timeout = setTimeout(function () {
        if (settled) return;
        settled = true;
        reject(new Error("YouTube API timed out."));
      }, 15000);

      window.onYouTubeIframeAPIReady = function () {
        if (typeof previousReady === "function") {
          try {
            previousReady();
          } catch (error) {
            console.warn("[DUAL] Previous YouTube callback failed:", error);
          }
        }
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        resolve(window.YT);
      };

      const existing = document.querySelector('script[src="https://www.youtube.com/iframe_api"]');
      if (existing) return;

      const script = document.createElement("script");
      script.src = "https://www.youtube.com/iframe_api";
      script.async = true;
      script.onerror = function () {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        reject(new Error("YouTube API failed to load."));
      };
      document.head.appendChild(script);
    });

    return youtubeApiPromise;
  }

  class MusicPlayer {
    constructor(root, profile) {
      this.root = root;
      this.profile = profile;
      this.config = profile.music;
      this.destroyed = false;
      this.provider = this.config.provider;
      this.isPlaying = false;
      this.isMuted = false;
      this.volume = typeof this.config.volume === "number" ? clamp(this.config.volume, 0, 1) : 0.5;
      this.lastVolume = this.volume > 0 ? this.volume : 0.5;
      this.progressTimer = null;
      this.startTimer = null;
      this.youtubePlayer = null;
      this.audioElement = null;
      this.audiomackFrame = null;
      this.spotifyFrame = null;
      this.userInitiated = false;

      this.elements = {
        stage: root.querySelector("[data-music-stage]"),
        playerMount: root.querySelector("[data-music-player]"),
        startButton: root.querySelector("[data-music-start]"),
        startReason: root.querySelector("[data-music-start-reason]"),
        toggle: root.querySelector("[data-music-toggle]"),
        toggleIcon: root.querySelector("[data-music-toggle-icon]"),
        mute: root.querySelector("[data-music-mute]"),
        muteIcon: root.querySelector("[data-music-mute-icon]"),
        volume: root.querySelector("[data-music-volume]"),
        seek: root.querySelector("[data-music-seek]"),
        elapsed: root.querySelector("[data-music-elapsed]"),
        duration: root.querySelector("[data-music-duration]"),
        note: root.querySelector("[data-music-note]"),
        hint: root.querySelector("[data-music-hint]"),
        progress: root.querySelector("[data-music-progress]"),
        controls: root.querySelector("[data-music-controls]"),
        artwork: root.querySelector("[data-music-art]"),
        title: root.querySelector("[data-music-title]"),
        subtitle: root.querySelector("[data-music-subtitle]"),
        artist: root.querySelector("[data-music-artist]"),
        providerLabel: root.querySelector("[data-music-provider-label]"),
        source: root.querySelector("[data-music-source]")
      };

      this.init();
    }

    init() {
      if (!this.config || !this.config.enabled) {
        if (this.root) this.root.hidden = true;
        return;
      }

      this.root.dataset.provider = this.provider;
      this.root.dataset.playing = "false";
      this.root.dataset.ready = "false";

      if (this.elements.artwork && this.config.artwork) {
        this.elements.artwork.src = this.config.artwork;
        if (this.config.artworkFallback) {
          this.elements.artwork.dataset.fallback = this.config.artworkFallback;
        }
      }

      if (this.elements.title) this.elements.title.textContent = this.config.title || "";
      if (this.elements.subtitle) this.elements.subtitle.textContent = this.config.subtitle || "";
      if (this.elements.artist) this.elements.artist.textContent = this.config.artist || "";
      if (this.elements.providerLabel) this.elements.providerLabel.textContent = this.config.providerLabel || this.provider.toUpperCase();
      if (this.elements.hint) this.elements.hint.textContent = this.config.hint || "";
      if (this.elements.source && this.config.sourceUrl) this.elements.source.href = this.config.sourceUrl;

      if (this.elements.volume) {
        const volumePercent = Math.round(this.volume * 100);
        this.elements.volume.value = String(volumePercent);
        setRangeFill(this.elements.volume, volumePercent);
      }

      setIcon(this.elements.toggleIcon, "play");
      setIcon(this.elements.muteIcon, this.isMuted ? "volume-off" : "volume");

      this.bindControls();

      if (this.provider === "audiomack") {
        this.initAudiomack();
      } else if (this.provider === "spotify") {
        this.initSpotify();
      } else if (this.provider === "youtube") {
        this.initYouTube();
      } else if (this.provider === "audio") {
        this.initAudio();
      } else {
        this.showNote("Unsupported music provider.");
      }

      players.add(this);
    }

    bindControls() {
      if (this.elements.toggle) {
        this.elements.toggle.addEventListener("click", () => {
          if (this.provider === "audiomack" || this.provider === "spotify") {
            this.play();
            return;
          }
          this.toggle();
        });
      }

      if (this.elements.startButton) {
        this.elements.startButton.addEventListener("click", () => {
          this.play();
        });
      }

      if (this.elements.mute) {
        this.elements.mute.addEventListener("click", () => {
          this.toggleMute();
        });
      }

      if (this.elements.volume) {
        this.elements.volume.addEventListener("input", (event) => {
          const value = Number(event.target.value) / 100;
          this.setVolume(value);
        });
      }

      if (this.elements.seek) {
        this.elements.seek.addEventListener("input", (event) => {
          const duration = this.getDuration();
          if (!duration) return;
          const value = (Number(event.target.value) / 1000) * duration;
          this.seek(value);
        });
      }
    }

    setPlaying(value) {
      this.isPlaying = Boolean(value);
      this.root.dataset.playing = this.isPlaying ? "true" : "false";
      if (this.elements.toggle) {
        setIcon(this.elements.toggleIcon, this.isPlaying ? "pause" : "play");
        this.elements.toggle.setAttribute("aria-label", this.isPlaying ? "Pause music" : "Play music");
      }
    }

    setMuted(value) {
      this.isMuted = Boolean(value);
      if (this.elements.mute) {
        setIcon(this.elements.muteIcon, this.isMuted ? "volume-off" : "volume");
        this.elements.mute.setAttribute("aria-label", this.isMuted ? "Unmute" : "Mute");
        this.elements.mute.setAttribute("aria-pressed", this.isMuted ? "true" : "false");
      }
    }

    setVolume(value) {
      this.volume = clamp(Number(value), 0, 1);
      if (this.volume > 0) this.lastVolume = this.volume;
      if (this.elements.volume) {
        setRangeFill(this.elements.volume, this.volume * 100);
      }
      if (this.provider === "youtube" && this.youtubePlayer && this.youtubePlayer.setVolume) {
        this.youtubePlayer.setVolume(Math.round(this.volume * 100));
        if (this.volume > 0 && this.isMuted) {
          this.youtubePlayer.unMute();
          this.setMuted(false);
        }
      }
      if (this.provider === "audio" && this.audioElement) {
        this.audioElement.volume = this.volume;
        if (this.volume > 0 && this.isMuted) {
          this.audioElement.muted = false;
          this.setMuted(false);
        }
      }
      if (this.volume === 0) {
        this.setMuted(true);
      }
    }

    toggleMute() {
      if (this.provider === "audiomack") return;
      const next = !this.isMuted;
      this.setMuted(next);
      if (this.provider === "youtube" && this.youtubePlayer) {
        if (next) this.youtubePlayer.mute();
        else this.youtubePlayer.unMute();
      }
      if (this.provider === "audio" && this.audioElement) {
        this.audioElement.muted = next;
      }
      if (!next && this.volume === 0) {
        this.setVolume(this.lastVolume);
      }
    }

    toggle() {
      if (this.isPlaying) this.pause();
      else this.play();
    }

    showStartOverlay(reason) {
      if (!this.elements.startButton) return;
      this.elements.startButton.hidden = false;
      this.root.dataset.needsGesture = "true";
      if (reason && this.elements.startReason) {
        this.elements.startReason.textContent = reason;
      }
    }

    hideStartOverlay() {
      if (!this.elements.startButton) return;
      this.elements.startButton.hidden = true;
      this.root.dataset.needsGesture = "false";
    }

    showNote(message) {
      if (this.elements.note) this.elements.note.textContent = message || "";
      if (this.elements.note) this.elements.note.hidden = !message;
    }

    updateTime(current, duration) {
      const safeDuration = Number.isFinite(duration) && duration > 0 ? duration : 0;
      const safeCurrent = Number.isFinite(current) && current > 0 ? current : 0;
      if (this.elements.elapsed) this.elements.elapsed.textContent = formatTime(safeCurrent);
      if (this.elements.duration) this.elements.duration.textContent = formatTime(safeDuration);
      if (this.elements.seek) {
        const percent = safeDuration ? (safeCurrent / safeDuration) * 100 : 0;
        this.elements.seek.value = String(Math.round(percent * 10));
        setRangeFill(this.elements.seek, percent);
        this.elements.seek.setAttribute("aria-valuetext", formatTime(safeCurrent) + " / " + formatTime(safeDuration));
      }
    }

    startProgressLoop() {
      this.stopProgressLoop();
      this.progressTimer = setInterval(() => {
        if (this.destroyed) return;
        if (this.provider === "youtube" && this.youtubePlayer && this.youtubePlayer.getCurrentTime) {
          const duration = this.youtubePlayer.getDuration ? this.youtubePlayer.getDuration() : 0;
          const current = this.youtubePlayer.getCurrentTime ? this.youtubePlayer.getCurrentTime() : 0;
          this.updateTime(current, duration);
        }
        if (this.provider === "audio" && this.audioElement) {
          this.updateTime(this.audioElement.currentTime, this.audioElement.duration);
        }
      }, 500);
    }

    stopProgressLoop() {
      clearInterval(this.progressTimer);
      this.progressTimer = null;
    }

    getDuration() {
      if (this.provider === "youtube" && this.youtubePlayer && this.youtubePlayer.getDuration) {
        return this.youtubePlayer.getDuration() || 0;
      }
      if (this.provider === "audio" && this.audioElement) {
        return this.audioElement.duration || 0;
      }
      return 0;
    }

    seek(seconds) {
      if (this.provider === "youtube" && this.youtubePlayer && this.youtubePlayer.seekTo) {
        this.youtubePlayer.seekTo(seconds, true);
      }
      if (this.provider === "audio" && this.audioElement) {
        this.audioElement.currentTime = seconds;
      }
    }

    initAudiomack() {
      this.root.dataset.external = "true";
      this.root.dataset.ready = "true";
      this.showNote("");
      if (this.elements.toggle) {
        setIcon(this.elements.toggleIcon, "play");
        this.elements.toggle.setAttribute("aria-label", "Start Audiomack music");
        this.elements.toggle.setAttribute("title", "Start music");
      }
      this.renderAudiomackEmbed(Boolean(this.config.autoplay));
    }

    renderAudiomackEmbed(autoplay) {
      if (!this.elements.stage || !this.config.embedUrl) return;
      this.elements.stage.innerHTML = "";
      this.elements.stage.classList.add("music-stage--audiomack");

      const frame = document.createElement("iframe");
      const url = new URL(this.config.embedUrl);
      url.searchParams.set("autoplay", autoplay ? "1" : "0");
      url.searchParams.set("_dual", String(Date.now()));
      frame.src = url.toString();
      frame.title = (this.config.title || "Audiomack") + " · Audiomack player";
      frame.loading = "eager";
      frame.allow = "autoplay; encrypted-media; fullscreen; picture-in-picture";
      frame.setAttribute("scrolling", "no");
      frame.setAttribute("frameborder", "0");
      frame.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
      this.elements.stage.appendChild(frame);
      this.audiomackFrame = frame;
      this.root.dataset.started = autoplay ? "true" : "false";
      if (this.elements.toggle) {
        this.elements.toggle.setAttribute("title", autoplay ? "Restart music" : "Start music");
        this.elements.toggle.setAttribute("aria-label", autoplay ? "Restart Audiomack music" : "Start Audiomack music");
      }
    }

    initSpotify() {
      this.root.dataset.external = "true";
      this.root.dataset.ready = "true";
      this.showNote("");
      if (this.elements.toggle) {
        setIcon(this.elements.toggleIcon, "play");
        this.elements.toggle.setAttribute("aria-label", "Start Spotify music");
        this.elements.toggle.setAttribute("title", "Start music");
      }
      this.renderSpotifyEmbed(Boolean(this.config.autoplay));
    }

    renderSpotifyEmbed(autoplay) {
      if (!this.elements.stage || !this.config.embedUrl) return;
      this.elements.stage.innerHTML = "";
      this.elements.stage.classList.add("music-stage--spotify");

      const frame = document.createElement("iframe");
      const url = new URL(this.config.embedUrl);
      if (autoplay) url.searchParams.set("autoplay", "1");
      url.searchParams.set("_dual", String(Date.now()));
      frame.src = url.toString();
      frame.title = (this.config.title || "Spotify") + " · Spotify player";
      frame.loading = "eager";
      frame.allow = "autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture";
      frame.setAttribute("scrolling", "no");
      frame.setAttribute("frameborder", "0");
      frame.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
      this.elements.stage.appendChild(frame);
      this.spotifyFrame = frame;
      this.root.dataset.started = autoplay ? "true" : "false";
      if (this.elements.toggle) {
        this.elements.toggle.setAttribute("title", autoplay ? "Reload music" : "Start music");
        this.elements.toggle.setAttribute("aria-label", autoplay ? "Reload Spotify music" : "Start Spotify music");
      }
    }

    play() {
      if (this.destroyed) return;
      if (this.provider === "audiomack") {
        this.renderAudiomackEmbed(true);
        this.root.dataset.started = "true";
        if (this.elements.toggle) {
          this.elements.toggle.setAttribute("title", "Restart music");
          this.elements.toggle.setAttribute("aria-label", "Restart Audiomack music");
        }
        return;
      }
      if (this.provider === "spotify") {
        this.renderSpotifyEmbed(true);
        this.root.dataset.started = "true";
        if (this.elements.toggle) {
          this.elements.toggle.setAttribute("title", "Reload music");
          this.elements.toggle.setAttribute("aria-label", "Reload Spotify music");
        }
        return;
      }
      if (this.provider === "youtube" && this.youtubePlayer && this.youtubePlayer.playVideo) {
        this.userInitiated = true;
        this.hideStartOverlay();
        this.youtubePlayer.playVideo();
        if (this.isMuted) this.youtubePlayer.unMute();
        clearTimeout(this.startTimer);
        this.startTimer = setTimeout(() => {
          if (this.destroyed || !this.youtubePlayer || !this.youtubePlayer.getPlayerState) return;
          const state = this.youtubePlayer.getPlayerState();
          if (state !== 1 && state !== 3) {
            this.setPlaying(false);
            this.root.dataset.error = "true";
            this.showStartOverlay("Music could not start. The browser or YouTube may be restricting playback.");
            this.showNote("This YouTube source cannot play on this page. You can open the official video on YouTube.");
          }
        }, 2600);
        return;
      }
      if (this.provider === "audio" && this.audioElement) {
        const promise = this.audioElement.play();
        if (promise && typeof promise.catch === "function") {
          promise.catch(() => {
            this.showStartOverlay("The browser blocked autoplay. Tap to start.");
          });
        }
      }
    }

    pause() {
      if (this.destroyed) return;
      if (this.provider === "audiomack") {
        this.renderAudiomackEmbed(false);
        return;
      }
      if (this.provider === "spotify") {
        this.renderSpotifyEmbed(false);
        return;
      }
      if (this.provider === "youtube" && this.youtubePlayer && this.youtubePlayer.pauseVideo) {
        this.youtubePlayer.pauseVideo();
        return;
      }
      if (this.provider === "audio" && this.audioElement) {
        this.audioElement.pause();
      }
    }

    async initYouTube() {
      if (!this.config.youtubeId) {
        this.showNote("No YouTube video ID is configured.");
        return;
      }
      if (!this.elements.stage) return;

      try {
        const YT = await loadYouTubeApi();
        if (this.destroyed) return;

        let mount = this.elements.playerMount;
        if (!mount) {
          mount = document.createElement("div");
          mount.className = "music-stage__player";
          mount.setAttribute("data-music-player", "");
          this.elements.stage.prepend(mount);
          this.elements.playerMount = mount;
        }

        const playerVars = {
          autoplay: 0,
          controls: 0,
          disablekb: 1,
          enablejsapi: 1,
          fs: 0,
          iv_load_policy: 3,
          modestbranding: 1,
          playsinline: 1,
          rel: 0,
          loop: this.config.loop ? 1 : 0,
          playlist: this.config.youtubeId
        };

        if (window.location.protocol === "http:" || window.location.protocol === "https:") {
          playerVars.origin = window.location.origin;
        }

        this.youtubePlayer = new YT.Player(mount, {
          videoId: this.config.youtubeId,
          host: "https://www.youtube.com",
          playerVars,
          events: {
            onReady: (event) => this.handleYouTubeReady(event),
            onStateChange: (event) => this.handleYouTubeState(event),
            onError: (event) => this.handleYouTubeError(event)
          }
        });
      } catch (error) {
        console.warn("[DUAL] YouTube player error:", error);
        this.showNote("The YouTube player failed to load. Open the page through an HTTP server.");
        this.root.dataset.error = "true";
      }
    }

    handleYouTubeReady(event) {
      if (this.destroyed) return;
      this.root.dataset.ready = "true";
      const player = event.target;
      player.setVolume(Math.round(this.volume * 100));
      if (this.isMuted) player.mute();
      this.updateTime(0, player.getDuration ? player.getDuration() : 0);
      this.startProgressLoop();

      if (this.config.autoplay) {
        try {
          player.playVideo();
        } catch (error) {
            this.showStartOverlay("The browser blocked autoplay. Tap to start.");
        }
        this.startTimer = setTimeout(() => {
          if (this.destroyed) return;
          const state = player.getPlayerState ? player.getPlayerState() : -1;
          if (state !== 1) {
            this.showStartOverlay("The browser blocked autoplay. Tap to start.");
          }
        }, 2200);
      }
    }

    handleYouTubeState(event) {
      if (this.destroyed) return;
      const state = event.data;
      if (state === 1) {
        clearTimeout(this.startTimer);
        this.hideStartOverlay();
        this.showNote("");
        this.setPlaying(true);
        const duration = this.youtubePlayer && this.youtubePlayer.getDuration ? this.youtubePlayer.getDuration() : 0;
        const current = this.youtubePlayer && this.youtubePlayer.getCurrentTime ? this.youtubePlayer.getCurrentTime() : 0;
        this.updateTime(current, duration);
      } else if (state === 2) {
        this.setPlaying(false);
      } else if (state === 0) {
        if (this.config.loop) {
          try {
            this.youtubePlayer.seekTo(0, true);
            this.youtubePlayer.playVideo();
          } catch (error) {
            this.setPlaying(false);
          }
        } else {
          this.setPlaying(false);
          this.updateTime(0, this.getDuration());
        }
      } else if (state === 5) {
        this.setPlaying(false);
      }
    }

    handleYouTubeError(event) {
      const code = event && event.data;
      console.warn("[DUAL] YouTube playback error:", code);

      if ((code === 150 || code === 101) && !this.userInitiated) {
        this.root.dataset.error = "false";
        this.showStartOverlay("The browser blocked autoplay. Tap to start.");
        this.setPlaying(false);
        return;
      }

      this.root.dataset.error = "true";
      this.showNote("This YouTube source cannot play on this page. You can open the official video on YouTube.");
      this.setPlaying(false);
    }

    initAudio() {
      if (!this.config.audioSrc) {
        this.showNote("No audio file is configured.");
        return;
      }
      const audio = document.createElement("audio");
      audio.src = this.config.audioSrc;
      audio.preload = "metadata";
      audio.loop = Boolean(this.config.loop);
      audio.volume = this.volume;
      audio.className = "music-audio";
      if (this.elements.stage) {
        this.elements.stage.appendChild(audio);
        this.elements.stage.classList.add("music-stage--audio");
      }
      this.audioElement = audio;
      this.root.dataset.ready = "true";

      audio.addEventListener("loadedmetadata", () => {
        this.updateTime(audio.currentTime, audio.duration);
      });
      audio.addEventListener("timeupdate", () => {
        this.updateTime(audio.currentTime, audio.duration);
      });
      audio.addEventListener("play", () => {
        this.hideStartOverlay();
        this.setPlaying(true);
      });
      audio.addEventListener("pause", () => {
        this.setPlaying(false);
      });
      audio.addEventListener("ended", () => {
        this.setPlaying(false);
        if (this.config.loop) {
          audio.currentTime = 0;
          audio.play().catch(() => {});
        }
      });
      audio.addEventListener("error", () => {
        this.showNote("The audio file failed to load.");
        this.root.dataset.error = "true";
      });

      if (this.config.autoplay) {
        const promise = audio.play();
        if (promise && typeof promise.catch === "function") {
          promise.catch(() => {
            this.showStartOverlay("The browser blocked autoplay. Tap to start.");
          });
        }
      }
    }

    destroy() {
      if (this.destroyed) return;
      this.destroyed = true;
      clearTimeout(this.startTimer);
      this.stopProgressLoop();
      players.delete(this);
      if (this.youtubePlayer && this.youtubePlayer.destroy) {
        try {
          this.youtubePlayer.destroy();
        } catch (error) {
          this.youtubePlayer = null;
        }
      }
      if (this.audioElement) {
        try {
          this.audioElement.pause();
          this.audioElement.removeAttribute("src");
          this.audioElement.load();
        } catch (error) {}
        this.audioElement = null;
      }
      if (this.audiomackFrame) {
        this.audiomackFrame.src = "about:blank";
        this.audiomackFrame.remove();
        this.audiomackFrame = null;
      }
      if (this.spotifyFrame) {
        this.spotifyFrame.src = "about:blank";
        this.spotifyFrame.remove();
        this.spotifyFrame = null;
      }
    }
  }

  function create(root, profile) {
    if (!root || !profile || !profile.music) return null;
    return new MusicPlayer(root, profile);
  }

  function pauseAll() {
    Array.from(players).forEach((player) => {
      if (player.destroyed) return;
      if (player.provider === "audiomack") {
        if (player.root.dataset.started === "true") {
          player.renderAudiomackEmbed(false);
        }
      } else if (player.provider === "spotify") {
        if (player.root.dataset.started === "true") {
          player.renderSpotifyEmbed(false);
        }
      } else {
        player.pause();
      }
    });
  }

  function stopAll() {
    Array.from(players).forEach((player) => player.destroy());
  }

  window.addEventListener("pagehide", function (event) {
    if (event.persisted) pauseAll();
  });

  window.CoupleMusic = {
    create,
    stopAll,
    pauseAll,
    formatTime
  };
})();
