(function () {
  "use strict";

  const config = window.COUPLE_CONFIG;
  const profileEntries = Object.entries(config.profiles);
  const idToKey = new Map(profileEntries.map(([key, profile]) => [String(profile.discordId), key]));
  const states = {};
  const listeners = new Map();

  let socket = null;
  let heartbeatTimer = null;
  let reconnectTimer = null;
  let unavailableTimer = null;
  let reconnectAttempt = 0;
  let lastMessageAt = 0;
  let connection = "idle";
  let started = false;
  let closedByPage = false;

  function emit(event, detail) {
    const handlers = listeners.get(event);
    if (!handlers) return;
    handlers.forEach((handler) => {
      try {
        handler(detail);
      } catch (error) {
        console.warn("[DUAL] Event handler failed:", error);
      }
    });
  }

  function on(event, handler) {
    if (typeof handler !== "function") return function () {};
    if (!listeners.has(event)) listeners.set(event, new Set());
    listeners.get(event).add(handler);
    return function () {
      const handlers = listeners.get(event);
      if (handlers) handlers.delete(handler);
    };
  }

  function setConnection(next, detail) {
    connection = next;
    emit("connection", { status: next, attempt: reconnectAttempt, detail: detail || null });
  }

  function initialState() {
    return {
      phase: "loading",
      data: null,
      error: null,
      fetchedAt: 0
    };
  }

  function setProfileState(key, next) {
    states[key] = Object.assign({}, states[key] || initialState(), next);
    emit("presence", { key, state: states[key] });
  }

  function markError(key, code, message) {
    setProfileState(key, {
      phase: code === "not_connected" ? "not_connected" : "error",
      data: null,
      error: { code, message },
      fetchedAt: Date.now()
    });
  }

  function normalizeAvatar(user) {
    if (!user || !user.avatar) return null;
    const extension = String(user.avatar).startsWith("a_") ? "gif" : "png";
    return "https://cdn.discordapp.com/avatars/" + user.id + "/" + user.avatar + "." + extension + "?size=512";
  }

  function normalize(presence) {
    const user = presence.discord_user || {};
    const activities = Array.isArray(presence.activities) ? presence.activities : [];
    const customStatus = activities.find((activity) => Number(activity.type) === 4) || null;
    const spotify = presence.listening_to_spotify && presence.spotify ? presence.spotify : null;

    return {
      discordId: String(user.id || ""),
      user: {
        id: String(user.id || ""),
        username: user.username || "",
        globalName: user.global_name || "",
        displayName: user.display_name || user.global_name || user.username || "",
        discriminator: user.discriminator || "0",
        avatar: user.avatar || null,
        avatarUrl: normalizeAvatar(user),
        avatarDecoration: user.avatar_decoration_data || null,
        bot: Boolean(user.bot)
      },
      status: presence.discord_status || "offline",
      activities,
      customStatus,
      spotify,
      listeningToSpotify: Boolean(spotify),
      platforms: {
        desktop: Boolean(presence.active_on_discord_desktop),
        mobile: Boolean(presence.active_on_discord_mobile),
        web: Boolean(presence.active_on_discord_web),
        embedded: Boolean(presence.active_on_discord_embedded),
        vr: Boolean(presence.active_on_discord_vr)
      },
      updatedAt: Date.now()
    };
  }

  function handlePresence(presence) {
    if (!presence || !presence.discord_user || !presence.discord_user.id) return;
    const key = idToKey.get(String(presence.discord_user.id));
    if (!key) return;
    setProfileState(key, {
      phase: "ready",
      data: normalize(presence),
      error: null,
      fetchedAt: Date.now()
    });
  }

  async function fetchProfile(key, options) {
    const profile = config.profiles[key];
    if (!profile) return;
    const settings = options || {};
    if (!settings.silent) {
      setProfileState(key, { phase: "loading", error: null });
    }

    try {
      const response = await fetch(config.lanyard.apiBase + "/users/" + encodeURIComponent(profile.discordId), {
        method: "GET",
        headers: { Accept: "application/json" },
        cache: "no-store"
      });

      if (response.status === 404) {
        markError(key, "not_connected", "This account has not joined the Lanyard server.");
        return;
      }

      if (!response.ok) {
        markError(key, "http_error", "Lanyard returned status " + response.status + ".");
        return;
      }

      const payload = await response.json();
      if (!payload || !payload.success || !payload.data) {
        markError(key, "invalid_response", "Lanyard returned an invalid response.");
        return;
      }

      setProfileState(key, {
        phase: "ready",
        data: normalize(payload.data),
        error: null,
        fetchedAt: Date.now()
      });
    } catch (error) {
      markError(key, "network_error", "The Lanyard API could not be reached.");
      console.warn("[DUAL] Lanyard REST error for " + key + ":", error);
    }
  }

  async function refresh(key) {
    if (key) {
      await fetchProfile(key);
      return;
    }
    await Promise.all(Object.keys(config.profiles).map((profileKey) => fetchProfile(profileKey, { silent: true })));
  }

  function subscribe() {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;
    const ids = profileEntries.map((entry) => entry[1].discordId);
    socket.send(JSON.stringify({
      op: 2,
      d: { subscribe_to_ids: ids }
    }));
  }

  function startHeartbeat(interval) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = setInterval(function () {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ op: 3 }));
      }
    }, interval);
  }

  function scheduleReconnect() {
    if (closedByPage) return;
    clearTimeout(reconnectTimer);
    const base = config.lanyard.reconnectBaseMs;
    const max = config.lanyard.reconnectMaxMs;
    const delay = Math.min(max, base * Math.pow(2, reconnectAttempt));
    const jitter = delay * (0.8 + Math.random() * 0.4);
    reconnectAttempt += 1;
    setConnection("reconnecting");
    reconnectTimer = setTimeout(connect, jitter);
  }

  function handleMessage(event) {
    lastMessageAt = Date.now();
    let payload;
    try {
      payload = JSON.parse(event.data);
    } catch (error) {
      return;
    }

    if (payload.op === 1) {
      const interval = payload.d && payload.d.heartbeat_interval ? payload.d.heartbeat_interval : 30000;
      startHeartbeat(interval);
      subscribe();
      reconnectAttempt = 0;
      setConnection("live");
      return;
    }

    if (payload.op === 0 && payload.t === "INIT_STATE") {
      const data = payload.d || {};
      Object.keys(data).forEach((userId) => handlePresence(data[userId]));
      setConnection("live");
      return;
    }

    if (payload.op === 0 && payload.t === "PRESENCE_UPDATE") {
      handlePresence(payload.d);
    }
  }

  function connect() {
    if (closedByPage) return;
    if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;

    clearTimeout(reconnectTimer);
    if (reconnectAttempt === 0) {
      setConnection("connecting");
    } else {
      setConnection("reconnecting");
    }

    try {
      socket = new WebSocket(config.lanyard.socketUrl);
    } catch (error) {
      console.warn("[DUAL] WebSocket could not be created:", error);
      scheduleReconnect();
      return;
    }

    socket.addEventListener("open", function () {
      lastMessageAt = Date.now();
    });

    socket.addEventListener("message", handleMessage);

    socket.addEventListener("close", function () {
      clearInterval(heartbeatTimer);
      heartbeatTimer = null;
      socket = null;
      if (closedByPage) {
        setConnection("offline");
        return;
      }
      scheduleReconnect();
    });

    socket.addEventListener("error", function () {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    });
  }

  function startUnavailableRetry() {
    clearInterval(unavailableTimer);
    unavailableTimer = setInterval(function () {
      if (document.visibilityState !== "visible") return;
      Object.keys(states).forEach(function (key) {
        const state = states[key];
        if (state.phase === "not_connected" || state.phase === "error") {
          fetchProfile(key, { silent: true });
        }
      });
    }, config.lanyard.unavailableRetryMs);
  }

  function handleVisibility() {
    if (document.visibilityState !== "visible") return;
    const stale = Date.now() - lastMessageAt > config.lanyard.restRefreshMs;
    if (stale) {
      refresh();
    }
  }

  function handleOnline() {
    if (closedByPage) return;
    if (!socket || socket.readyState === WebSocket.CLOSED) {
      reconnectAttempt = 0;
      connect();
    }
  }

  function handleOffline() {
    setConnection("offline");
  }

  function handlePageHide() {
    closedByPage = true;
    clearTimeout(reconnectTimer);
    clearInterval(heartbeatTimer);
    clearInterval(unavailableTimer);
    heartbeatTimer = null;
    unavailableTimer = null;
    if (socket) {
      try {
        socket.close();
      } catch (error) {
        socket = null;
      }
    }
    socket = null;
  }

  function handlePageShow(event) {
    if (!event.persisted) return;
    closedByPage = false;
    reconnectAttempt = 0;
    refresh();
    connect();
    startUnavailableRetry();
  }

  function init() {
    if (started) return;
    started = true;
    closedByPage = false;
    Object.keys(config.profiles).forEach(function (key) {
      states[key] = initialState();
    });

    Object.keys(config.profiles).forEach(function (key) {
      fetchProfile(key);
    });

    connect();
    startUnavailableRetry();

    document.addEventListener("visibilitychange", handleVisibility);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    window.addEventListener("pagehide", handlePageHide);
    window.addEventListener("pageshow", handlePageShow);
  }

  function getState(key) {
    return states[key] || initialState();
  }

  function getConnection() {
    return connection;
  }

  window.CoupleDiscord = {
    init,
    refresh,
    getState,
    getConnection,
    on
  };
})();
